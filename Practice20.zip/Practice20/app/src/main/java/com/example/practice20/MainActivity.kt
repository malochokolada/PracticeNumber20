package com.example.practice20

import android.R
import android.app.Activity
import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.view.Display
import android.view.Surface
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import java.util.*


class MainActivity : Activity() {
  var tvText: TextView? = null
  var sensorManager: SensorManager? = null
  var sensorAccel: Sensor? = null
  var sensorMagnet: Sensor? = null
  var sb = StringBuilder()
  var timer: Timer? = null
  var rotation = 0
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_list_item)
    tvText = findViewById(R.id.text1)
    sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
    sensorAccel = sensorManager!!.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    sensorMagnet = sensorManager!!.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
  }

  override fun onResume() {
    super.onResume()
    sensorManager!!.registerListener(listener, sensorAccel, SensorManager.SENSOR_DELAY_NORMAL)
    sensorManager!!.registerListener(listener, sensorMagnet, SensorManager.SENSOR_DELAY_NORMAL)
    timer = Timer()
    val task: TimerTask = object : TimerTask() {
      override fun run() {
        runOnUiThread {
          deviceOrientation
          actualDeviceOrientation
          
        }
      }
    }
    timer!!.schedule(task, 0, 5)
    val windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    val display: Display = windowManager.defaultDisplay
    rotation = display.getRotation()
  }

  override fun onPause() {
    super.onPause()
    sensorManager!!.unregisterListener(listener)
    timer!!.cancel()
  }

  fun format(values: FloatArray): String {
    return String.format("%1$.1f\t\t%2$.1f\t\t%3$.1f", values[0], values[1], values[2])
  }

  fun showInfo(view:View) {
    sb.setLength(0)
    sb.append("Orientation : " + format(valuesResult))
    tvText!!.text = sb
  }

  var r = FloatArray(9)
  val deviceOrientation: Unit
    get() {
      SensorManager.getRotationMatrix(r, null, valuesAccel, valuesMagnet)
      SensorManager.getOrientation(r, valuesResult)
      valuesResult[0] = Math.toDegrees(valuesResult[0].toDouble()).toFloat()
      valuesResult[1] = Math.toDegrees(valuesResult[1].toDouble()).toFloat()
      valuesResult[2] = Math.toDegrees(valuesResult[2].toDouble()).toFloat()
      return
    }
  var inR = FloatArray(9)
  var outR = FloatArray(9)
  val actualDeviceOrientation: Unit
    get() {
      SensorManager.getRotationMatrix(inR, null, valuesAccel, valuesMagnet)
      var x_axis = SensorManager.AXIS_X
      var y_axis = SensorManager.AXIS_Y
      when (rotation) {
        Surface.ROTATION_0 -> {}
        Surface.ROTATION_90 -> {
          x_axis = SensorManager.AXIS_Y
          y_axis = SensorManager.AXIS_MINUS_X
        }
        Surface.ROTATION_180 -> y_axis = SensorManager.AXIS_MINUS_Y
        Surface.ROTATION_270 -> {
          x_axis = SensorManager.AXIS_MINUS_Y
          y_axis = SensorManager.AXIS_X
        }
        else -> {}
      }
      SensorManager.remapCoordinateSystem(inR, x_axis, y_axis, outR)
      SensorManager.getOrientation(outR, valuesResult2)
      valuesResult2[0] = Math.toDegrees(valuesResult2[0].toDouble()).toFloat()
      valuesResult2[1] = Math.toDegrees(valuesResult2[1].toDouble()).toFloat()
      valuesResult2[2] = Math.toDegrees(valuesResult2[2].toDouble()).toFloat()
      return
    }
  var valuesAccel = FloatArray(3)
  var valuesMagnet = FloatArray(3)
  var valuesResult = FloatArray(3)
  var valuesResult2 = FloatArray(3)
  var listener: SensorEventListener = object : SensorEventListener {
    override fun onAccuracyChanged(sensor: Sensor, accuracy: Int) {}
    override fun onSensorChanged(event: SensorEvent) {
      when (event.sensor.type) {
        Sensor.TYPE_ACCELEROMETER -> {
          var i = 0
          while (i < 3) {
            valuesAccel[i] = event.values[i]
            i++
          }
        }
        Sensor.TYPE_MAGNETIC_FIELD -> {
          var i = 0
          while (i < 3) {
            valuesMagnet[i] = event.values[i]
            i++
          }
        }
      }
    }
  }
}

